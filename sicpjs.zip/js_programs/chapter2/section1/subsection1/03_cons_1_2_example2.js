const x = pair(1, 2);
tail(x);

// expected: 2
