const v = make_rect(make_point(0, 1), make_point(2, 3));

perimeter_rect(v);
