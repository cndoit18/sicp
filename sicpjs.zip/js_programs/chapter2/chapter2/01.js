function linear_combination(a, b, x, y) {
    return a * x + b * y;
}

linear_combination(1, 2, 3, 4);
