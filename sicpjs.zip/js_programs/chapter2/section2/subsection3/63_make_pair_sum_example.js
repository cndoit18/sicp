make_pair_sum(list(8, 9));
