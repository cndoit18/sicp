// brooks_curried to be written by the student
