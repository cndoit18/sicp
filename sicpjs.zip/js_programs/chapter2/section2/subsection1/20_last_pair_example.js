// last_pair to be given by student
last_pair(list(23, 72, 149, 34));
