const squares = list(1, 4, 9, 16, 25);
