const x = list(1, 2, 3);

const y = list(4, 5, 6);
