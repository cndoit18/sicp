// tree_map to be written by student
function square_tree(tree) { return tree_map(square, tree); }
