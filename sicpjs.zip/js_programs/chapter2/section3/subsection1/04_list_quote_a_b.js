const a = 1;
const b = 2;
list("a", b);

// expected: [ 'a', [ 2, null ] ]
