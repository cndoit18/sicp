// function equal to be written by student
