list(list("george"));
// [["george", null], null]

// expected: [ [ 'george', null ], null ]
