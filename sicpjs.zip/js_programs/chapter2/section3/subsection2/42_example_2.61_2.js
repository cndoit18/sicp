deriv(list("x", "*", 4), "x");
