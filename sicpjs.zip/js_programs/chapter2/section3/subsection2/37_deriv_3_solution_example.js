deriv(list("*", "x", "y", list("+", "x", 3)), "x");
