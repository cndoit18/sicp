head(tail(head(tail(deriv(list("**", "x", 4), "x")))));
