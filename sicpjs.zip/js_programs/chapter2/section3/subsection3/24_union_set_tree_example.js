tree_to_list_2(union_set_as_tree(
                    list_to_tree(list(1, 3, 5, 7)),
                    list_to_tree(list(2, 4, 6, 8)) ) );
