head(make_leaf_set( list( make_leaf("A", 4),
                          make_leaf("B", 2),
                          make_leaf("C", 1),
                          make_leaf("D", 1) ) ) );
