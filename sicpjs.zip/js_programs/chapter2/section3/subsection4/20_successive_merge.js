// successive_merge function to be written by student
