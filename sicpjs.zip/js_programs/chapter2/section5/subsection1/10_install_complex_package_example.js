const r = make_complex_from_real_imag(4, 3);
const p = make_complex_from_mag_ang(5, 0.5);
tail(add(r, p));
